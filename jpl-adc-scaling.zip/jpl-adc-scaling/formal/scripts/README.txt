Note: Version 10.6a of Qverify requires running on a rhel 6 machine. Currently 
that means running on dline17.
