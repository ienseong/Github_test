# Jobrnr Plug-ins

This directory contains plug-ins that extend the functionality of [Jobrnr][1] for
our needs.  See `jobrnr --help-plugin` for Jobrnr plug-in API details.

[1]: http://www.github.com/rfdonnelly/jobrnr

## Use

Add this directory to the `JOBRNR_PLUGIN_PATH` environment variable.

## Documentation

Documentation is done using [YARD][2], an inline documentation tool.  The
documentation can be read inline with the sourcecode or in HTML format.

Generate HTML documentation:

```
yardoc
```

[2]: http://yardoc.org


