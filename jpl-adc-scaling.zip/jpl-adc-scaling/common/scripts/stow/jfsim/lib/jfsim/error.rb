module JFSim
  class EnvironmentError < JF::Error; end
  class UsageError < JF::Error; end
end
