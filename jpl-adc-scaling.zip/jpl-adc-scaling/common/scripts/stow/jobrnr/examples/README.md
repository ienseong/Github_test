# examples

Each example exists in its own sub-directory.  The `index.jr` file in each example is the entry point for the example.  Unless noted otherwise in example specific README, examples are run with:

    bin/jobrnr index.jr
