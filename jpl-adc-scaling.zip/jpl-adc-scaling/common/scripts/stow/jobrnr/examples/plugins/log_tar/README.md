# LogTar Plugin Example

     JOBRNR_PLUGIN_PATH=$PWD/examples/plugins/log_tar bin/jobrnr examples/import/index.jr
