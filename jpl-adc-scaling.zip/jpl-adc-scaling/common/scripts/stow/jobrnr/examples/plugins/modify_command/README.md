# ModifyCommand Plugin Example

     JOBRNR_PLUGIN_PATH=$PWD/examples/plugins/modify_command bin/jobrnr examples/import/index.jr
