# Multiple Parents

Run with `--max-failures` greater than 1.

```sh
bin/jobrnr examples/multiple-parents/index.jr --max-failures 2
```
