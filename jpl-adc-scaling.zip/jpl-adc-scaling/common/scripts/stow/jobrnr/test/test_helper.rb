require 'minitest/autorun'

require 'jobrnr'
