module JF
  class Error < RuntimeError; end
end
