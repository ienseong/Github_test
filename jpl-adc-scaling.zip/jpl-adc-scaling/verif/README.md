# Simulation README

* Open Questa Sim
* In the transcript window:
  * `cd` to this directory
  * `do run.do`
  * If you get a message asking to overwrite the current project, click "Yes".
* The simulation will run and display PASS or FAIL at the end.
* Detailed information can be found in the simulation log: jpl_adc_scaling_log.txt